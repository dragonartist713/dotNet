namespace Interfaces{
	interface IWebComponent{
		string GenerateHtml();
	}
}