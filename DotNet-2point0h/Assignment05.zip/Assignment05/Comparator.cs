public class Comparator{
    public bool Compare<T>(T first, T second){
        return first.Equals(second);
    }
}