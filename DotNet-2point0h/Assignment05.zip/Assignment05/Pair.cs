public class Pair<T,U> {
    public T First;
    public U Second;


    // Generic property
    public T Item { get; set; }
}