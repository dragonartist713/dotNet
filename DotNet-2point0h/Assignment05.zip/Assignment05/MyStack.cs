// using System.Collections;
// class MyStack<T>{

//     public MyStack<T>{
        
//     }
    
//     public void Push(T item) {

//     }

//     public T Pop() {
        
//     }

//     public bool IsEmpty(List<T> list) {
//         if (list.Any()){
//             return false;
//         }
//         return true;
//     }
// }