namespace Interfaces{
    public interface IPrintable{
        void PrintDetails();
    }
}