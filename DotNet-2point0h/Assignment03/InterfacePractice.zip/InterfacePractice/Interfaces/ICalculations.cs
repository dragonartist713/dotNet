namespace Interfaces{
    public interface ICalculations{
        int Add(int one, int two);
        int Subtract(int one, int two);
    }
}