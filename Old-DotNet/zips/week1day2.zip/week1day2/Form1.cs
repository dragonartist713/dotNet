namespace week1day2
{
    public partial class Form1 : Form
    {
        private void bntClear_Click(object sender, EventArgs e)
        {

        }

        private void btnSubmit_Click(object sender, EventArgs e)
        {

        }
    }
}